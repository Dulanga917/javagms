/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymdao;

/**
 *
 * @author A C E R
 */
public class listofmember1dao {
    

public class listOfMember1DAO {
    private final ItemView view;
    private final ItemDAO dao;

    public listOfMember1DAO(ItemView view, ItemDAO dao) {
        this.view = view;
        this.dao = dao;
        initComponents();
    }

    private void initComponents() {
        // Implementation for initializing components
    }

    public void addMember1(Member member) {
        String sql = "INSERT INTO members (name, mobileNumber, email, gender, address, fatherName, gymTime, age, idNumber, amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = dao.getConnection(); // Assuming ItemDAO has a method to get a DB connection
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, member.getName());
            stmt.setString(2, member.getMobileNumber());
            stmt.setString(3, member.getEmail());
            stmt.setString(4, member.getGender());
            stmt.setString(5, member.getAddress());
            stmt.setString(6, member.getFatherName());
            stmt.setString(7, member.getGymTime());
            stmt.setString(8, member.getAge());
            stmt.setString(9, member.getIdNumber());
            stmt.setString(10, member.getAmount());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Consider better error handling
        }
    }
}

    
}
