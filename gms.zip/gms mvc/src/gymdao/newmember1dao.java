/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymdao;

import gymdb.DBConnection;
import gymmodel.newmember1model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author A C E R
 */
public class newmember1dao {
    
    public void add( newmember1model member){
        
        System.out.println(member);

        String sql ="INSERT INTO member1(name,mobilenumber,email,gender,address,fathername,gymtime,age,idnumber,amount) values (?,?,?,?,?,?,?,?,?,?)";
          try{
              Connection connection =DBConnection.get();
              PreparedStatement stmt =connection.prepareStatement(sql);
             
              stmt.setString(1,member.getName());
              stmt.setString(2,member.getMobilenumber());
              stmt.setString(3,member.getEmail());
              stmt.setString(4,member.getGender());
              stmt.setString(5,member.getAddress());
              stmt.setString(6,member.getFathername());
              stmt.setString(7,member.getGymtime());
              stmt.setString(8,member.getAge());
              stmt.setString(9,member.getIdnumber());
              stmt.setString(10,member.getAmount());
              
  
              stmt.executeUpdate();
              
          }catch (SQLException e){
              e.printStackTrace();
          }
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
