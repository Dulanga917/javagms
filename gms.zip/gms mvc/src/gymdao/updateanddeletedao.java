/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymdao;

import javax.swing.JOptionPane;

/**
 *
 * @author A C E R
 */
ublic class updateanddelete {
    private final updateanddelete view;
    private  itemDAO dao;

    public updateanddelete(itemView view) {
        this.view = view;
         this.dao = new itemDAO(); 
        initComponents();
    }
    public void delete(int id) {
        try {
            dao.delete(id);
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
        }
    }
    public void update1(itemModel item ) {
     
        try {
            dao.update(item);
           
        } catch (Exception e) {
            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
        }
    }

    private static class itemModel {

        public itemModel() {
        }
    }
//public class updateanddelete {
//    private final updateanddelete view;
//    private  itemDAO dao;
//
//    public updateanddelete(itemView view) {
//        this.view = view;
//         this.dao = new itemDAO(); 
//        initComponents();
//    }
//    public void delete(int id) {
//        try {
//            dao.delete(id);
//            
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
//        }
//    }
//    public void update1(itemModel item ) {
//     
//        try {
//            dao.update(item);
//           
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(view, "Error deleting user: " + e.getMessage());
//        }
//    }
//
//    private static class itemModel {
//
//        public itemModel() {
//        }
//    }
//    
//}
