/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymmodel;

/**
 *
 * @author A C E R
 */
public class paymentmodel {
    String sql;
        sql = "INSERT INTO product1b1(PName,category,price) VALUES(?,?,?)";
        try{
            Connection connection = DBConnection.getConnection();
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1,item.getName());
            stmt.setString(2,item.getCategory());
            stmt.setString(3,item.getPrice());
         
            stmt.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    
}
