/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymmodel;

/**
 *
 * @author A C E R
 */
public class updateanddeletemember1model {
    public class ItemModel {
    private int id;
    private String name;
        private String email;
        private String mobilenumber;
        private String gender;
        private String address;
        private String fathername;
        private String gymtime;
        private String amount;
        private String age;

    // Getters and setters for id and name
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
     public String getemail(String email) {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }
     public String mobilenumber() {
        return mobilenumber;
    }

    public void mobilenumber(String mobilenumber) {
        this.mobilenumber = mobilenumber;
    }
    public String gender() {
        return gender;
    }

    public void gender(String gender) {
        this.gender = gender;
    
    }public String address() {
        return address;
    }
    
    static {public void (String address) {
        this.address = address;
    }
    public String fathername() {
        return fathername;
    }

    public void fathername(String fathername) {
        this.fathername = fathername;
    }
    public String gymtime() {
        return gymtime;
    }

    public void gymtime(String gymtime) {
        this.gymtime = gymtime;
    }
    public String age() {
        String age = null;
        return age;
    }

    public void age(String age) {
        this.age = age;
    }
    public String idnumber() {
        String idnumber = null;
        return idnumber;
    }

    public void idnumber(String mobilenumber) {
        this.idnumber = idnumber;
    }
    public String amount() {
        return amount;
    }

    public void amount(String amount) {
        this.amount = amount;
    }
    }
}


    
    

    

